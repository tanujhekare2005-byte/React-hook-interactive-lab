
import { useState } from "react";
export function UseStateLab() {
  const [count, setCount] = useState(0);
  return (
    <>
      <p>useState example</p>
      <button onClick={() => setCount(count + 1)}>Count: {count}</button>
    </>
  );
}
