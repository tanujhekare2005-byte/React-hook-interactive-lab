
export default function Header() {
  return <h2 style={{padding:10}}>React Hooks Interactive Lab</h2>;
}
