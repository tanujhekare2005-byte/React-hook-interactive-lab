
export default function LabViewer({ lab }) {
  return <div style={{padding:20}}>{lab || "Select a hook"}</div>;
}
